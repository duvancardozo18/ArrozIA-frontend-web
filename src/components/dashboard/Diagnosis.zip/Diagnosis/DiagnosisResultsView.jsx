import React from 'react';

const DiagnosisResultsView = ({ results, onRetakeImages, onSaveDiagnosis }) => {
  return (
    <div className="diagnosis-results-view">
      <h2>Resultados del Diagnóstico</h2>
      <div className="results">
        {results.map((result, index) => (
          <div key={index} className="result-item">
            <img src={result.imageUrl} alt={`Resultado ${index}`} width="200" />
            <div className="result-details">
              <p><strong>Detecciones:</strong></p>
              {result.detections.map((detection, idx) => (
                <p key={idx}>{detection.nombre} - Confianza: {detection.confianza}%</p>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div className="actions">
        <button onClick={onRetakeImages}>Capturar Nuevas Imágenes</button>
        <button onClick={onSaveDiagnosis}>Guardar Diagnóstico</button>
      </div>
    </div>
  );
};

export default DiagnosisResultsView;