import React, { useContext, useEffect, useState } from 'react';
import { AuthContext } from '../../../config/AuthProvider';
import Header from '../Header';
import { Navigate } from 'react-router-dom';
import CropCard from './CropCard';
import ImageCaptureForm from '../../../components/dashboard/diagnosis/ImageCaptureForm';
import ImageUploadHandler from '../../../components/dashboard/diagnosis/ImageUploadHandler';
import DiagnosisResultsView from '../../../components/dashboard/diagnosis/DiagnosisResultsView';
import DiagnosisHistory from './DiagnosisHistory';
import styled from 'styled-components'; // Añadir esta línea
import axiosInstance from '../../../config/AxiosInstance';
import '../../../css/CropCard.scss';

// Definición de componentes de estilo utilizando styled-components
const Container = styled.div`
  display: flex;
  padding: 20px;
`;

const Sidebar = styled.div`
  width: 30%;
  padding-right: 20px;
  border-right: 1px solid #ddd;
`;

const Content = styled.div`
  width: 70%;
  padding-left: 20px;
`;

const CropSelection = () => {
  const { isAuthenticated } = useContext(AuthContext);
  const [crops, setCrops] = useState([]);
  const [selectedCropId, setSelectedCropId] = useState(null);
  const [images, setImages] = useState([]);
  const [results, setResults] = useState(null);
  const [viewHistory, setViewHistory] = useState(false);

  useEffect(() => {
    const fetchCrops = async () => {
      try {
        const response = await axiosInstance.get('/crops/all');
        setCrops(response.data);
      } catch (error) {
        console.error('Error fetching crops:', error);
      }
    };

    fetchCrops();
  }, []);

  const handleCropSelection = (cropId) => {
    setSelectedCropId(cropId);
    setResults(null);
    setImages([]);
  };

  const handleImagesSelected = (selectedImages) => {
    setImages(selectedImages);
  };

  const handleUploadImages = () => {
    const formData = new FormData();
    images.forEach((image) => {
      formData.append('images', image);
    });

    axiosInstance.post('/api/diagnosis/upload', formData)
      .then(response => {
        setResults(response.data);
      })
      .catch(error => {
        console.error('Error uploading images:', error);
      });
  };

  const handleRetakeImages = () => {
    setImages([]);
    setResults(null);
  };

  const handleSaveDiagnosis = () => {
    // Logic to save diagnosis
  };

  if (!isAuthenticated) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="content-area">
      <Header title="Diagnóstico Fitosanitario" />
      <Container>
        <Sidebar>
          <h2>Cultivos</h2>
          {crops.map((crop) => (
            <CropCard
              key={crop.id}
              cropName={crop.nombre_cultivo}
              onClick={() => handleCropSelection(crop.id)}
            />
          ))}
        </Sidebar>
        <Content>
          {!selectedCropId && <p>Seleccione un cultivo para iniciar el diagnóstico.</p>}

          {selectedCropId && !images.length && !results && (
            <ImageCaptureForm onImagesSelected={handleImagesSelected} />
          )}

          {images.length > 0 && !results && (
            <ImageUploadHandler images={images} onUploadComplete={handleUploadImages} />
          )}

          {results && (
            <DiagnosisResultsView
              results={results}
              onRetakeImages={handleRetakeImages}
              onSaveDiagnosis={handleSaveDiagnosis}
            />
          )}

          {selectedCropId && viewHistory && (
            <DiagnosisHistory selectedCrop={selectedCropId} />
          )}
        </Content>
      </Container>
    </div>
  );
};

export default CropSelection;
