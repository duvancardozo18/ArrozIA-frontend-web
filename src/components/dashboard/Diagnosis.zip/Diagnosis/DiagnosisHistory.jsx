import React, { useEffect, useState } from 'react';
import axios from 'axios';

const DiagnosisHistory = ({ selectedCrop }) => {
  const [history, setHistory] = useState([]);

  useEffect(() => {
    // Fetch the diagnosis history for the selected crop from the backend
    axios.get(`/api/diagnosis/history/${selectedCrop}`)
      .then(response => {
        setHistory(response.data);
      })
      .catch(error => {
        console.error('Error fetching diagnosis history:', error);
      });
  }, [selectedCrop]);

  return (
    <div className="diagnosis-history">
      <h2>Historial de Diagnósticos</h2>
      <div className="history-list">
        {history.map((item, index) => (
          <div key={index} className="history-item">
            <img src={item.imageUrl} alt={`Historial ${index}`} width="100" />
            <div className="history-details">
              <p><strong>Fecha:</strong> {item.fecha}</p>
              <p><strong>Resumen:</strong> {item.resumen}</p>
              <button onClick={() => console.log(`Ver detalles de ${item.id}`)}>Ver Detalles</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DiagnosisHistory;