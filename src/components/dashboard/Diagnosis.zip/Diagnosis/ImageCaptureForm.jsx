import React, { useState } from 'react';

const ImageCaptureForm = ({ onImagesSelected }) => {
  const [selectedImages, setSelectedImages] = useState([]);

  const handleImageCapture = (event) => {
    const files = Array.from(event.target.files);
    setSelectedImages(files);
  };

  const handleImageSelection = () => {
    onImagesSelected(selectedImages);
  };

  return (
    <div className="image-capture-form">
      <h2>Captura o Selección de Imágenes</h2>
      <input
        type="file"
        accept="image/*"
        multiple
        onChange={handleImageCapture}
      />
      <div className="image-preview">
        {selectedImages.map((image, index) => (
          <img
            key={index}
            src={URL.createObjectURL(image)}
            alt={`preview-${index}`}
            width="100"
          />
        ))}
      </div>
      <button onClick={handleImageSelection} disabled={selectedImages.length === 0}>Enviar Imágenes</button>
    </div>
  );
};

export default ImageCaptureForm;